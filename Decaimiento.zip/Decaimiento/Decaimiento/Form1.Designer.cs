﻿
namespace Decaimiento
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDecaimientoInicial = new System.Windows.Forms.TextBox();
            this.txtTasaDecaimiento = new System.Windows.Forms.TextBox();
            this.txtDistanciaMax = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSimular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtDecaimientoInicial
            // 
            this.txtDecaimientoInicial.Location = new System.Drawing.Point(61, 59);
            this.txtDecaimientoInicial.Name = "txtDecaimientoInicial";
            this.txtDecaimientoInicial.Size = new System.Drawing.Size(100, 20);
            this.txtDecaimientoInicial.TabIndex = 0;
            // 
            // txtTasaDecaimiento
            // 
            this.txtTasaDecaimiento.Location = new System.Drawing.Point(180, 59);
            this.txtTasaDecaimiento.Name = "txtTasaDecaimiento";
            this.txtTasaDecaimiento.Size = new System.Drawing.Size(100, 20);
            this.txtTasaDecaimiento.TabIndex = 1;
            // 
            // txtDistanciaMax
            // 
            this.txtDistanciaMax.Location = new System.Drawing.Point(306, 59);
            this.txtDistanciaMax.Name = "txtDistanciaMax";
            this.txtDistanciaMax.Size = new System.Drawing.Size(100, 20);
            this.txtDistanciaMax.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Decaimiento Inicial";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(180, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tasa de Decaimiento";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(306, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Distancia";
            // 
            // btnSimular
            // 
            this.btnSimular.Location = new System.Drawing.Point(64, 137);
            this.btnSimular.Name = "btnSimular";
            this.btnSimular.Size = new System.Drawing.Size(75, 23);
            this.btnSimular.TabIndex = 6;
            this.btnSimular.Text = "Resultado";
            this.btnSimular.UseVisualStyleBackColor = true;
            this.btnSimular.Click += new System.EventHandler(this.btnSimular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(13, 10);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(126, 13);
            this.lblResultado.TabIndex = 7;
            this.lblResultado.Text = "Resultados del Simulador";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Controls.Add(this.lblResultado);
            this.panel1.Location = new System.Drawing.Point(183, 137);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(245, 121);
            this.panel1.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 326);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnSimular);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDistanciaMax);
            this.Controls.Add(this.txtTasaDecaimiento);
            this.Controls.Add(this.txtDecaimientoInicial);
            this.Name = "Form1";
            this.Text = "Simulador de modelo de decaimiento por cristales y distancia";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDecaimientoInicial;
        private System.Windows.Forms.TextBox txtTasaDecaimiento;
        private System.Windows.Forms.TextBox txtDistanciaMax;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSimular;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Panel panel1;
    }
}

